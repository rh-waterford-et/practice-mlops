feast package
=============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   feast.api
   feast.cli
   feast.diff
   feast.dqm
   feast.embedded_go
   feast.infra
   feast.lineage
   feast.loaders
   feast.permissions
   feast.protos
   feast.transformation
   feast.ui

Submodules
----------

feast.aggregation module
------------------------

.. automodule:: feast.aggregation
   :members:
   :undoc-members:
   :show-inheritance:

feast.arrow\_error\_handler module
----------------------------------

.. automodule:: feast.arrow_error_handler
   :members:
   :undoc-members:
   :show-inheritance:

feast.base\_feature\_view module
--------------------------------

.. automodule:: feast.base_feature_view
   :members:
   :undoc-members:
   :show-inheritance:

feast.batch\_feature\_view module
---------------------------------

.. automodule:: feast.batch_feature_view
   :members:
   :undoc-members:
   :show-inheritance:

feast.constants module
----------------------

.. automodule:: feast.constants
   :members:
   :undoc-members:
   :show-inheritance:

feast.data\_format module
-------------------------

.. automodule:: feast.data_format
   :members:
   :undoc-members:
   :show-inheritance:

feast.data\_source module
-------------------------

.. automodule:: feast.data_source
   :members:
   :undoc-members:
   :show-inheritance:

feast.document\_labeling module
-------------------------------

.. automodule:: feast.document_labeling
   :members:
   :undoc-members:
   :show-inheritance:

feast.driver\_test\_data module
-------------------------------

.. automodule:: feast.driver_test_data
   :members:
   :undoc-members:
   :show-inheritance:

feast.entity module
-------------------

.. automodule:: feast.entity
   :members:
   :undoc-members:
   :show-inheritance:

feast.errors module
-------------------

.. automodule:: feast.errors
   :members:
   :undoc-members:
   :show-inheritance:

feast.feast\_object module
--------------------------

.. automodule:: feast.feast_object
   :members:
   :undoc-members:
   :show-inheritance:

feast.feature module
--------------------

.. automodule:: feast.feature
   :members:
   :undoc-members:
   :show-inheritance:

feast.feature\_logging module
-----------------------------

.. automodule:: feast.feature_logging
   :members:
   :undoc-members:
   :show-inheritance:

feast.feature\_server module
----------------------------

.. automodule:: feast.feature_server
   :members:
   :undoc-members:
   :show-inheritance:

feast.feature\_service module
-----------------------------

.. automodule:: feast.feature_service
   :members:
   :undoc-members:
   :show-inheritance:

feast.feature\_store module
---------------------------

.. automodule:: feast.feature_store
   :members:
   :undoc-members:
   :show-inheritance:

feast.feature\_view module
--------------------------

.. automodule:: feast.feature_view
   :members:
   :undoc-members:
   :show-inheritance:

feast.feature\_view\_projection module
--------------------------------------

.. automodule:: feast.feature_view_projection
   :members:
   :undoc-members:
   :show-inheritance:

feast.field module
------------------

.. automodule:: feast.field
   :members:
   :undoc-members:
   :show-inheritance:

feast.file\_utils module
------------------------

.. automodule:: feast.file_utils
   :members:
   :undoc-members:
   :show-inheritance:

feast.flags\_helper module
--------------------------

.. automodule:: feast.flags_helper
   :members:
   :undoc-members:
   :show-inheritance:

feast.grpc\_error\_interceptor module
-------------------------------------

.. automodule:: feast.grpc_error_interceptor
   :members:
   :undoc-members:
   :show-inheritance:

feast.importer module
---------------------

.. automodule:: feast.importer
   :members:
   :undoc-members:
   :show-inheritance:

feast.inference module
----------------------

.. automodule:: feast.inference
   :members:
   :undoc-members:
   :show-inheritance:

feast.names module
------------------

.. automodule:: feast.names
   :members:
   :undoc-members:
   :show-inheritance:

feast.nlp\_test\_data module
----------------------------

.. automodule:: feast.nlp_test_data
   :members:
   :undoc-members:
   :show-inheritance:

feast.offline\_server module
----------------------------

.. automodule:: feast.offline_server
   :members:
   :undoc-members:
   :show-inheritance:

feast.on\_demand\_feature\_view module
--------------------------------------

.. automodule:: feast.on_demand_feature_view
   :members:
   :undoc-members:
   :show-inheritance:

feast.online\_response module
-----------------------------

.. automodule:: feast.online_response
   :members:
   :undoc-members:
   :show-inheritance:

feast.project module
--------------------

.. automodule:: feast.project
   :members:
   :undoc-members:
   :show-inheritance:

feast.project\_metadata module
------------------------------

.. automodule:: feast.project_metadata
   :members:
   :undoc-members:
   :show-inheritance:

feast.proto\_json module
------------------------

.. automodule:: feast.proto_json
   :members:
   :undoc-members:
   :show-inheritance:

feast.rag\_retriever module
---------------------------

.. automodule:: feast.rag_retriever
   :members:
   :undoc-members:
   :show-inheritance:

feast.registry\_server module
-----------------------------

.. automodule:: feast.registry_server
   :members:
   :undoc-members:
   :show-inheritance:

feast.repo\_config module
-------------------------

.. automodule:: feast.repo_config
   :members:
   :undoc-members:
   :show-inheritance:

feast.repo\_contents module
---------------------------

.. automodule:: feast.repo_contents
   :members:
   :undoc-members:
   :show-inheritance:

feast.repo\_operations module
-----------------------------

.. automodule:: feast.repo_operations
   :members:
   :undoc-members:
   :show-inheritance:

feast.rest\_error\_handler module
---------------------------------

.. automodule:: feast.rest_error_handler
   :members:
   :undoc-members:
   :show-inheritance:

feast.saved\_dataset module
---------------------------

.. automodule:: feast.saved_dataset
   :members:
   :undoc-members:
   :show-inheritance:

feast.ssl\_ca\_trust\_store\_setup module
-----------------------------------------

.. automodule:: feast.ssl_ca_trust_store_setup
   :members:
   :undoc-members:
   :show-inheritance:

feast.stream\_feature\_view module
----------------------------------

.. automodule:: feast.stream_feature_view
   :members:
   :undoc-members:
   :show-inheritance:

feast.torch\_wrapper module
---------------------------

.. automodule:: feast.torch_wrapper
   :members:
   :undoc-members:
   :show-inheritance:

feast.transformation\_server module
-----------------------------------

.. automodule:: feast.transformation_server
   :members:
   :undoc-members:
   :show-inheritance:

feast.type\_map module
----------------------

.. automodule:: feast.type_map
   :members:
   :undoc-members:
   :show-inheritance:

feast.types module
------------------

.. automodule:: feast.types
   :members:
   :undoc-members:
   :show-inheritance:

feast.ui\_server module
-----------------------

.. automodule:: feast.ui_server
   :members:
   :undoc-members:
   :show-inheritance:

feast.utils module
------------------

.. automodule:: feast.utils
   :members:
   :undoc-members:
   :show-inheritance:

feast.value\_type module
------------------------

.. automodule:: feast.value_type
   :members:
   :undoc-members:
   :show-inheritance:

feast.vector\_store module
--------------------------

.. automodule:: feast.vector_store
   :members:
   :undoc-members:
   :show-inheritance:

feast.version module
--------------------

.. automodule:: feast.version
   :members:
   :undoc-members:
   :show-inheritance:

feast.wait module
-----------------

.. automodule:: feast.wait
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast
   :members:
   :undoc-members:
   :show-inheritance:
